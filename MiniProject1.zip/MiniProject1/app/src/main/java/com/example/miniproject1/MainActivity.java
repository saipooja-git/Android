package com.example.miniproject1;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Apply window insets to the main layout
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Find the cycle button by ID
        Button cycleBTN = findViewById(R.id.cycleBTN);

        // Find the display TextView
        TextView displayTV = findViewById(R.id.displayTV);

        // Set the cycle button click listener
        cycleBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the current text from the display
                String displayText = displayTV.getText().toString();

                // Find the first occurrence of "LR"
                int index = displayText.indexOf("LR");

                // If "LR" is found, perform the cycle operation
                if (index != -1) {
                    // Split the string into two parts: before and after "LR"
                    String firstPart = displayText.substring(0,index+1);  // String before the first "LR"
                    String secondPart = displayText.substring(index + 1); // String after "LR"

                    // Cycle the two parts (swap positions)
                    String cycledText = secondPart + firstPart;

                    // Set the new cycled text back to the display
                    displayTV.setText(cycledText);
                }
            }
        });
    }

    // Existing swapAction method for the swap button
    public void swapAction(View v) {
        TextView displayTV = findViewById(R.id.displayTV);
        String contents = displayTV.getText().toString();
        int loc = contents.indexOf("RL");
        Log.d("app", "loc is " + loc);
        if (loc >= 0) {
            contents = contents.replace("RL", "LR");
        }
        displayTV.setText(contents);
    }
}
