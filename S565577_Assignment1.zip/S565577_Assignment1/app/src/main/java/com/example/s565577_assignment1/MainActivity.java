package com.example.s565577_assignment1;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnDisplay,btnBTD,btnHex,btn2Complement,btnComplement;
    private TextView displayTV,tView,textExc;
    private EditText etValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        displayTV = findViewById(R.id.displayTV);
        btnDisplay = findViewById(R.id.btnDisplay);
        etValue = findViewById(R.id.etValue);
        tView = findViewById(R.id.tView);
        textExc = findViewById(R.id.textExc);
        btnHex = findViewById(R.id.btnHex);
        btnComplement = findViewById(R.id.btnComplement);
        btn2Complement = findViewById(R.id.btn2Complement);
        btnBTD=findViewById(R.id.btnBTD);





        // Set up the button click listener
        btnDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertToBinary();
            }
        });

        btnBTD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        btnComplement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleComplement();
            }
        });

        btnHex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                convertToHex();

            }
        });

        btn2Complement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleTwosComplement();
            }
        });
    }

    // Method to convert number to binary and update TextView
    private void convertToBinary() {
        try {
            String input = etValue.getText().toString();

            if (input.isEmpty()) {
                displayTV.setText("00000000000000000000000000000000");
                return;
            }

            // Convert input to integer
            int number = Integer.parseInt(input);

            // Convert number to binary
            String binaryString = Integer.toBinaryString(number);

            // Ensure the binary string is padded to 32 bits
            String paddedBinaryString = String.format("%32s", binaryString).replace(' ', '0');

            // Display the result
            displayTV.setText(paddedBinaryString);

        } catch (NumberFormatException e) {
            // Display default 32-bit zero string for invalid input
            displayTV.setText("00000000000000000000000000000000");
        }
    }

    private void convertToHex(){
        try{
            String binaryInput = displayTV.getText().toString();

            if(binaryInput.isEmpty()||binaryInput.equals("no result")){
                displayTV.setText("00000000000000000000000000000000");
            }

            int decimalValue = Integer.parseUnsignedInt(binaryInput,2);

            String hexResult = Integer.toHexString(decimalValue).toUpperCase();
            displayTV.setText(hexResult);
        } catch( Exception e){
            displayTV.setText("Error");
        }
    }

    private void handleComplement() {
        try {
            String binaryInput = displayTV.getText().toString();
            if (binaryInput.length() != 32) {
                textExc.setText("Binary input must be 32 bits.");
                return;
            }
            String complement = binaryInput.replace('0', '2').replace('1', '0').replace('2', '1');
            displayTV.setText(complement);
            textExc.setText(""); // Clear exception text
        } catch (Exception e) {
            textExc.setText("Error: " + e.getMessage());
        }
    }

    // 2's Complement (flip and add 1)
    private void handleTwosComplement() {
        try {
            String binaryInput = displayTV.getText().toString();
            if (binaryInput.length() != 32) {
                textExc.setText("Binary input must be 32 bits.");
                return;
            }

            // Parse binary as unsigned
            int decimalValue = Integer.parseUnsignedInt(binaryInput, 2);
            // Take two's complement
            int twosComplementValue = ~decimalValue + 1;
            String binaryResult = Integer.toBinaryString(twosComplementValue);

            // Ensure it's 32 bits
            if (binaryResult.length() > 32) {
                binaryResult = binaryResult.substring(binaryResult.length() - 32);
            } else {
                binaryResult = String.format("%32s", binaryResult).replace(' ', '0');
            }

            displayTV.setText(binaryResult);
            textExc.setText(""); // Clear exception text
        } catch (Exception e) {
            textExc.setText("Error: " + e.getMessage());
        }
    }
    private void handleBinaryToDecimal() {
        try {
            String binaryInput = displayTV.getText().toString();
            if (binaryInput.length() != 32) {
                textExc.setText("Binary input must be 32 bits.");
                return;
            }

            int decimalValue = Integer.parseUnsignedInt(binaryInput, 2);
            etValue.setText(String.valueOf(decimalValue));
            textExc.setText(""); // Clear exception text
        } catch (Exception e) {
            textExc.setText("Error: " + e.getMessage());
        }
    }
}
