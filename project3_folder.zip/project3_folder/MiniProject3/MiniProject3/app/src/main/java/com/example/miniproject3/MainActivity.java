package com.example.miniproject3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Existing button handler for AdditionActivity
        Button sendBTN = findViewById(R.id.sendBTN);
        sendBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addIntent = new Intent(getApplicationContext(), AdditionActivity.class);
                addIntent.putExtra("first", 10.0);
                addIntent.putExtra("second", 15.0);
                startActivity(addIntent);
            }
        });

        // New button handler to launch StringRepeatActivity
        Button startRepeatActivityBTN = findViewById(R.id.startRepeatActivityBTN);
        startRepeatActivityBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an intent for StringRepeatActivity with extras
                Intent repeatIntent = new Intent(getApplicationContext(), StringRepeatActivity.class);
                repeatIntent.putExtra("repeat", 5);  // Repeat count is 5
                repeatIntent.putExtra("data", "NA"); // Data is "NA"
                startActivity(repeatIntent);
            }
        });
    }
}
