package com.example.miniproject3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class StringRepeatActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stringrepeatactivity);

        // Get the intent and extract the extras
        Intent intent = getIntent();
        int repeatCount = intent.getIntExtra("repeat", 1);  // Default to 1 if not provided
        String data = intent.getStringExtra("data");

        // Repeat the string the specified number of times
        StringBuilder repeatedString = new StringBuilder();
        for (int i = 0; i < repeatCount; i++) {
            repeatedString.append(data);
        }

        // Display the repeated string in the TextView
        TextView repeatTextView = findViewById(R.id.repeatTextView);
        repeatTextView.setText(repeatedString.toString());

        // Set up the button to finish the activity
        Button finishButton = findViewById(R.id.finishButton);
        finishButton.setOnClickListener(view -> finish());
    }
}
